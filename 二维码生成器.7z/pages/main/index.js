// pages/main/index.js
var QR = require("../../utils/qrcode.js");
//二维码生成器
Page({
  data:{
   
    maskHidden:true,
    imagePath:'',
    placeholder:'t.tt'
  },
  onLoad:function(options){
    var size = this.setCanvasSize();//动态设置画布大小
    var initUrl = "http://"+this.data.placeholder;
    this.createQrCode(initUrl,"mycanvas",size.w,size.h);
  },
  onReady:function(){
    
  },
  onShow:function(){
  },
  onHide:function(){
  },

  onUnload:function(){
  
  },
  //在这里我们考虑到了也许这个小程序要用在不同的手机上，所以这个图片的大小
  //它不是固定的，而是通过获取手机的系统信息，进行匹配运算
  setCanvasSize:function(){
    var size={};//包含图片的长宽
    try {
        var res = wx.getSystemInfoSync();//获取这台手机的系统信息，作为进行匹配的原始数据
        var scale = 750/686;//不同屏幕下图片的比例
        var width = res.windowWidth/scale;//获得手机界面的大小
        var height = width;//画布为正方形
        size.w = width;
        size.h = height;
      } catch (e) {
        // Do something when catch error
        console.log("获取设备信息失败"+e);//如果获取设备信息失败就写这个
      } 
    return size;//把整个图片大小信息返回至主函数
  } ,
  createQrCode:function(url,canvasId,cavW,cavH){
    //调用插件中的draw方法，绘制二维码图片
    //由于实在写不出来二维码的生成方式，只能使用插件
    QR.qrApi.draw(url,canvasId,cavW,cavH);
    //url为在文本框中输入的网址，此函数将把文本转二维码
    var that = this;
    //二维码生成之后调用canvasToTempImage();延迟1s，否则获取图片路径为空
    var st = setTimeout(function(){
      that.canvasToTempImage();
      clearTimeout(st);
    },1000);
    
  },
  //获取临时缓存照片路径，存入data中
  canvasToTempImage:function(){
    var that = this;
    wx.canvasToTempFilePath({//创建临时文件保存路径
      canvasId: 'mycanvas',
      success: function (res) {
          var tempFilePath = res.tempFilePath;
          console.log(tempFilePath);
          that.setData({
              imagePath:tempFilePath,
          });
      },
      fail: function (res) {
          console.log(res);
      }
    });
  },
  //点击图片进行预览，长按保存分享图片
  //这功能要在微信开发者工具中使用
  previewImg:function(e){
    var img = this.data.imagePath
    wx.previewImage({
      current: img, // 当前显示图片的http链接
      urls: [img] // 需要预览的图片http链接列表
    })
  },
  formSubmit: function(e) {
    var that = this;
    var url = e.detail.value.url;
    url = url==''?('http://'+that.data.placeholder):('http://'+url);
    //如果没有输入，就默认为t.tt，否则变为http://“你输入的网站”
    that.setData({
      maskHidden:false,//生成成功，显示图片
    });
    wx.showToast({//在生成好之前弹出等待界面
      title: '正在生成中……',
      icon: 'loading',
      duration:2000
    });
    var st = setTimeout(function(){
      wx.hideToast()//生成好了，就关闭“loading”弹出框
      var size = that.setCanvasSize();
      //绘制二维码
      that.createQrCode(url,"mycanvas",size.w,size.h);
      //这个函数之前已经声明
      that.setData({
        maskHidden:true//重新初始化图片
      });
      clearTimeout(st);
    },2000)
    
  }

})